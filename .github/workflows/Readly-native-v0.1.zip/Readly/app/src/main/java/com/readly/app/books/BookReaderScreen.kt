package com.readly.app.books

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.readly.app.data.Book
import com.readly.app.data.LocalStorage
import com.readly.app.ui.components.Centered
import com.readly.app.ui.components.ReadlyTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.snapshotFlow
import java.io.File

@Composable
fun BookReaderScreen(id: String, nav: NavHostController) {
    val ctx = LocalContext.current
    val store = remember { LocalStorage(ctx) }
    val bm = remember { BookManager(ctx, store) }
    val book = remember { store.books().find { it.id == id } }
    var fs by remember { mutableIntStateOf(store.fontSize) }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        ReadlyTopBar(book?.title ?: "Reader", onBack = { nav.popBackStack() }, actions = {
            if (book?.type == "txt") {
                TextButton({ fs = (fs - 2).coerceAtLeast(12); store.fontSize = fs }) { Text("A-") }
                TextButton({ fs = (fs + 2).coerceAtMost(34); store.fontSize = fs }) { Text("A+") }
            }
        })
        when {
            book == null -> Centered("Book not found")
            !bm.file(book).exists() -> Centered("File missing from this device")
            book.type == "pdf" -> PdfReader(book, bm.file(book), store)
            else -> TxtReader(book, bm.file(book), store, fs)
        }
    }
}

@Composable
private fun TxtReader(book: Book, file: File, store: LocalStorage, fontSize: Int) {
    var paras by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(book.id) {
        paras = withContext(Dispatchers.IO) {
            file.readText().split(Regex("\n\\s*\n")).map { it.trim() }.filter { it.isNotEmpty() }
        }
    }
    val list = paras
    if (list == null) { Centered("Opening…"); return }
    if (list.isEmpty()) { Centered("This file is empty"); return }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = store.position(book.id).coerceIn(0, list.lastIndex))
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex }.collect { store.setProgress(book.id, it, list.size) }
    }
    LazyColumn(state = state, contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(list) { _, p -> Text(p, fontSize = fontSize.sp, lineHeight = (fontSize * 1.6f).sp) }
    }
}

@Composable
private fun PdfReader(book: Book, file: File, store: LocalStorage) {
    val pfd = remember { ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY) }
    val renderer = remember { PdfRenderer(pfd) }
    DisposableEffect(Unit) { onDispose { renderer.close(); pfd.close() } }
    val count = renderer.pageCount
    var page by remember { mutableIntStateOf(store.position(book.id).coerceIn(0, count - 1)) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    val widthPx = (LocalConfiguration.current.screenWidthDp * LocalDensity.current.density).toInt()

    LaunchedEffect(page) {
        store.setProgress(book.id, page, count)
        bmp = withContext(Dispatchers.IO) {
            synchronized(renderer) {
                val p = renderer.openPage(page)
                try {
                    Bitmap.createBitmap(widthPx, widthPx * p.height / p.width, Bitmap.Config.ARGB_8888).also {
                        it.eraseColor(android.graphics.Color.WHITE)
                        p.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                } finally { p.close() }
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState(), enabled = true)) {
            bmp?.let { Image(it.asImageBitmap(), "Page ${page + 1}", Modifier.fillMaxWidth()) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton({ page-- }, enabled = page > 0) { Text("Previous") }
            Text("${page + 1} / $count")
            TextButton({ page++ }, enabled = page < count - 1) { Text("Next") }
        }
    }
}
