package com.readly.app.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.userProfileChangeRequest
import kotlinx.coroutines.tasks.await

object AuthManager {
    private val auth get() = FirebaseAuth.getInstance()
    val user: FirebaseUser? get() = auth.currentUser

    /** Firebase persists the session on-device across restarts and reboots by itself. */
    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun signUp(name: String, email: String, password: String) {
        val u = auth.createUserWithEmailAndPassword(email.trim(), password).await().user!!
        u.updateProfile(userProfileChangeRequest { displayName = name.trim() }).await()
    }

    fun signOut() = auth.signOut()

    fun addListener(l: FirebaseAuth.AuthStateListener) = auth.addAuthStateListener(l)
    fun removeListener(l: FirebaseAuth.AuthStateListener) = auth.removeAuthStateListener(l)
}
