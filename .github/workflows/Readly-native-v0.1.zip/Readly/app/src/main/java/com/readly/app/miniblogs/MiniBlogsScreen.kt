package com.readly.app.miniblogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.readly.app.auth.AuthManager
import com.readly.app.data.FirebaseManager
import com.readly.app.data.Post
import com.readly.app.data.categories
import com.readly.app.ui.components.Centered
import com.readly.app.ui.components.ReadlyCard
import com.readly.app.ui.components.ReadlyTopBar
import java.text.DateFormat
import java.util.Date

@Composable
fun MiniBlogsScreen(nav: NavHostController) {
    var tab by remember { mutableStateOf("Latest") }
    var cat by remember { mutableStateOf<String?>(null) }
    var posts by remember { mutableStateOf<List<Post>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(tab) {
        posts = null; error = null
        try { posts = FirebaseManager.feed(tab, AuthManager.user?.uid) }
        catch (e: Exception) { error = e.message ?: "Couldn't load posts" }
    }
    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = { ReadlyTopBar("Mini Blogs") },
        floatingActionButton = {
            FloatingActionButton({ nav.navigate("writer") }, containerColor = MaterialTheme.colorScheme.secondary) {
                Icon(Icons.Default.Add, "Write a post")
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Latest", "Popular", "My Posts").forEach {
                    FilterChip(tab == it, { tab = it }, label = { Text(it) })
                }
            }
            LazyRow(contentPadding = PaddingValues(16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(cat == null, { cat = null }, label = { Text("All") }) }
                items(categories) { c -> FilterChip(cat == c, { cat = if (cat == c) null else c }, label = { Text(c) }) }
            }
            val list = posts?.filter { cat == null || it.category == cat }
            when {
                error != null -> Centered(error!!)
                list == null -> Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
                list.isEmpty() -> Centered(if (tab == "My Posts") "You haven't posted yet. Tap + to write." else "No posts here yet.")
                else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(list, key = { it.id }) { PostCard(it) { nav.navigate("blog/${it.id}") } }
                }
            }
        }
    }
}

@Composable
private fun PostCard(p: Post, onClick: () -> Unit) {
    ReadlyCard(Modifier.fillMaxWidth(), onClick) {
        Text("${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(p.createdAt))} · ${p.authorName} · ${p.category}",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        if (p.imageUrl.isNotEmpty()) {
            AsyncImage(p.imageUrl, null, Modifier.fillMaxWidth().height(160.dp), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(8.dp))
        }
        Text(p.title, style = MaterialTheme.typography.titleMedium)
        Text(p.body, maxLines = 4, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
