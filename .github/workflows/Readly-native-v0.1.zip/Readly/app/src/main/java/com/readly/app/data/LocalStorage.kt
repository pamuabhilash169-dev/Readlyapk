package com.readly.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LocalStorage(ctx: Context) {
    private val p = ctx.getSharedPreferences("readly", Context.MODE_PRIVATE)

    fun books(): List<Book> {
        val a = JSONArray(p.getString("books", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Book(o.getString("id"), o.getString("title"), o.getString("author"),
                o.getString("file"), o.getString("type"), o.getLong("size"), o.getLong("added"))
        }
    }

    fun saveBooks(list: List<Book>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("author", it.author)
                .put("file", it.file).put("type", it.type).put("size", it.size).put("added", it.added))
        }
        p.edit().putString("books", a.toString()).apply()
    }

    fun position(id: String) = p.getInt("pos_$id", 0)
    fun total(id: String) = p.getInt("tot_$id", 0)
    fun setProgress(id: String, pos: Int, total: Int) {
        p.edit().putInt("pos_$id", pos).putInt("tot_$id", total).apply()
    }
    fun percent(id: String): Int { val t = total(id); return if (t <= 1) 0 else position(id) * 100 / (t - 1) }

    var theme: String
        get() = p.getString("theme", "dark") ?: "dark"
        set(v) = p.edit().putString("theme", v).apply()
    var fontSize: Int
        get() = p.getInt("font", 18)
        set(v) = p.edit().putInt("font", v).apply()

    // Logout clears session-related state only; books and progress stay on the device.
    fun clearSession() { p.edit().remove("session_uid").apply() }
}
