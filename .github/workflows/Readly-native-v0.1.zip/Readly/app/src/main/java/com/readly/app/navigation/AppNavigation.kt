package com.readly.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.google.firebase.auth.FirebaseAuth
import com.readly.app.auth.AuthManager
import com.readly.app.auth.LoginScreen
import com.readly.app.books.*
import com.readly.app.circle.MyCircleScreen
import com.readly.app.home.HomeScreen
import com.readly.app.miniblogs.*
import com.readly.app.settings.SettingsScreen

private data class Tab(val route: String, val label: String, val icon: ImageVector)
private val tabs = listOf(
    Tab("home", "Home", Icons.Default.Home),
    Tab("books", "Books", Icons.AutoMirrored.Filled.List),
    Tab("blogs", "Blogs", Icons.Default.Edit),
    Tab("circle", "Circle", Icons.Default.Person),
    Tab("settings", "Settings", Icons.Default.Settings)
)

fun NavHostController.goTab(route: String) = navigate(route) {
    popUpTo(graph.findStartDestination().id) { saveState = true }
    launchSingleTop = true; restoreState = true
}

@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    var loggedIn by remember { mutableStateOf(AuthManager.user != null) }
    val start = remember { if (AuthManager.user != null) "home" else "login" }

    // Any sign-out (explicit or server-side) sends the user back to Login.
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { loggedIn = it.currentUser != null }
        AuthManager.addListener(l)
        onDispose { AuthManager.removeListener(l) }
    }
    LaunchedEffect(loggedIn) {
        if (!loggedIn && nav.currentDestination?.route != "login") {
            nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
        }
    }

    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (tabs.any { it.route == route }) NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route, onClick = { nav.goTab(t.route) },
                        icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, start, Modifier.padding(pad)) {
            composable("login") {
                LoginScreen { nav.navigate("home") { popUpTo("login") { inclusive = true } } }
            }
            composable("home") { HomeScreen(nav) }
            composable("books") { BooksScreen(nav) }
            composable("book/{id}") { BookDetailsScreen(it.arguments!!.getString("id")!!, nav) }
            composable("reader/{id}") { BookReaderScreen(it.arguments!!.getString("id")!!, nav) }
            composable("blogs") { MiniBlogsScreen(nav) }
            composable("blog/{id}") { BlogDetailScreen(it.arguments!!.getString("id")!!, nav) }
            composable("writer?id={id}") { WriterStudioScreen(it.arguments?.getString("id"), nav) }
            composable("circle") { MyCircleScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
