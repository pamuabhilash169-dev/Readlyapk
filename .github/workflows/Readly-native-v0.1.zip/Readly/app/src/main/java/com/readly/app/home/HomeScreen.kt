package com.readly.app.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.readly.app.auth.AuthManager
import com.readly.app.navigation.goTab
import com.readly.app.ui.components.ReadlyCard

@Composable
fun HomeScreen(nav: NavHostController) {
    val name = AuthManager.user?.displayName?.takeIf { it.isNotBlank() } ?: "reader"
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Readly", style = MaterialTheme.typography.headlineMedium)
        Text("Welcome back, $name", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        listOf(
            Triple("Books", "Your offline library", "books"),
            Triple("Mini Blogs", "Read and write short posts", "blogs"),
            Triple("My Circle", "Coming soon", "circle"),
            Triple("Settings", "Account, reading, privacy", "settings")
        ).forEach { (t, s, r) ->
            ReadlyCard(Modifier.fillMaxWidth(), onClick = { nav.goTab(r) }) {
                Text(t, style = MaterialTheme.typography.titleMedium)
                Text(s, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
