package com.readly.app.books

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.readly.app.data.Book
import com.readly.app.data.LocalStorage
import com.readly.app.ui.components.Centered
import com.readly.app.ui.components.ReadlyTopBar
import kotlinx.coroutines.launch

@Composable
fun BooksScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val store = remember { LocalStorage(ctx) }
    val bm = remember { BookManager(ctx, store) }
    var books by remember { mutableStateOf(store.books().sortedByDescending { it.added }) }
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            var skipped = 0
            uris.forEach { if (bm.import(it) == null) skipped++ }
            books = store.books().sortedByDescending { it.added }
            if (skipped > 0) snack.showSnackbar("$skipped file(s) skipped. Only PDF and TXT are supported for now.")
        }
    }
    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        topBar = { ReadlyTopBar("Books") },
        floatingActionButton = {
            FloatingActionButton({ picker.launch(arrayOf("application/pdf", "text/plain")) }, containerColor = MaterialTheme.colorScheme.secondary) {
                Icon(Icons.Default.Add, "Import books")
            }
        }
    ) { pad ->
        if (books.isEmpty()) Box(Modifier.padding(pad)) { Centered("No books yet. Tap + to import a PDF or TXT from your device.") }
        else LazyVerticalGrid(
            GridCells.Adaptive(140.dp), Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(books, key = { it.id }) { b -> BookCard(b, bm, store) { nav.navigate("book/${b.id}") } }
        }
    }
}

@Composable
private fun BookCard(b: Book, bm: BookManager, store: LocalStorage, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.7f).clip(RoundedCornerShape(12.dp))
                .then(Modifier), contentAlignment = Alignment.Center
        ) {
            val cover = bm.cover(b)
            if (cover != null) AsyncImage(cover, b.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surfaceVariant) {
                Box(contentAlignment = Alignment.Center) {
                    Text(b.type.uppercase(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
        Text("${b.author} · ${store.percent(b.id)}%", color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
    }
}
