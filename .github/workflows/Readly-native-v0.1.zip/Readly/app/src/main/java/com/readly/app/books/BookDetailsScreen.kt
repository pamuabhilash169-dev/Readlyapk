package com.readly.app.books

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.readly.app.data.LocalStorage
import com.readly.app.ui.components.Centered
import com.readly.app.ui.components.ReadlyTopBar
import java.text.DateFormat
import java.util.Date

@Composable
fun BookDetailsScreen(id: String, nav: NavHostController) {
    val ctx = LocalContext.current
    val store = remember { LocalStorage(ctx) }
    val bm = remember { BookManager(ctx, store) }
    var book by remember { mutableStateOf(store.books().find { it.id == id }) }
    var confirm by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    val b = book
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        ReadlyTopBar("Book details", onBack = { nav.popBackStack() })
        if (b == null) { Centered("Book not found"); return@Column }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            bm.cover(b)?.let { AsyncImage(it, b.title, Modifier.height(260.dp).align(androidx.compose.ui.Alignment.CenterHorizontally), contentScale = ContentScale.Fit) }
            Text(b.title, style = MaterialTheme.typography.headlineMedium)
            Text(b.author, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${b.type.uppercase()} · ${"%.1f".format(b.size / 1_048_576.0)} MB · added ${DateFormat.getDateInstance().format(Date(b.added))}")
            Text("Read ${store.percent(b.id)}%")
            Button({ nav.navigate("reader/${b.id}") }, Modifier.fillMaxWidth()) {
                Text(if (store.total(b.id) > 0) "Continue reading" else "Start reading")
            }
            OutlinedButton({ edit = true }, Modifier.fillMaxWidth()) { Text("Edit title & author") }
            OutlinedButton({ confirm = true }, Modifier.fillMaxWidth()) { Text("Remove from device") }
        }
    }
    if (confirm && b != null) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Remove book?") }, text = { Text("The file is deleted from this device. Your original file is untouched.") },
        confirmButton = { TextButton({ bm.delete(b); nav.popBackStack() }) { Text("Remove") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
    )
    if (edit && b != null) {
        var t by remember { mutableStateOf(b.title) }
        var a by remember { mutableStateOf(b.author) }
        AlertDialog(
            onDismissRequest = { edit = false }, title = { Text("Edit") },
            text = { Column {
                OutlinedTextField(t, { t = it }, label = { Text("Title") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(a, { a = it }, label = { Text("Author") }, singleLine = true)
            } },
            confirmButton = { TextButton({
                val nb = b.copy(title = t.ifBlank { b.title }, author = a.ifBlank { b.author }); bm.update(nb); book = nb; edit = false
            }) { Text("Save") } },
            dismissButton = { TextButton({ edit = false }) { Text("Cancel") } }
        )
    }
}
