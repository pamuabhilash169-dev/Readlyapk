package com.readly.app.books

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.readly.app.data.Book
import com.readly.app.data.LocalStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** User-owned local books only. Files are copied into app-private storage so they work offline. */
class BookManager(private val ctx: Context, private val store: LocalStorage) {
    private val booksDir get() = File(ctx.filesDir, "books").apply { mkdirs() }
    private val coversDir get() = File(ctx.filesDir, "covers").apply { mkdirs() }

    fun file(b: Book) = File(booksDir, b.file)
    fun cover(b: Book) = File(coversDir, "${b.id}.png").takeIf { it.exists() }

    suspend fun import(uri: Uri): Book? = withContext(Dispatchers.IO) {
        var name = "Untitled"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext != "pdf" && ext != "txt") return@withContext null
        val id = UUID.randomUUID().toString()
        val dest = File(booksDir, "$id.$ext")
        ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { i.copyTo(it) } } ?: return@withContext null
        val book = Book(id, name.substringBeforeLast('.'), "Unknown author", dest.name, ext, dest.length(), System.currentTimeMillis())
        if (ext == "pdf") makePdfCover(book, dest)
        store.saveBooks(store.books() + book)
        book
    }

    private fun makePdfCover(b: Book, f: File) {
        var pfd: ParcelFileDescriptor? = null
        var r: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            r = PdfRenderer(pfd)
            val p = r.openPage(0)
            try {
                val w = 400
                val bmp = Bitmap.createBitmap(w, w * p.height / p.width, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                File(coversDir, "${b.id}.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
            } finally { p.close() }
        } catch (_: Exception) {
        } finally { r?.close(); pfd?.close() }
    }

    fun update(b: Book) = store.saveBooks(store.books().map { if (it.id == b.id) b else it })

    fun delete(b: Book) {
        file(b).delete(); cover(b)?.delete()
        store.saveBooks(store.books().filter { it.id != b.id })
    }
}
