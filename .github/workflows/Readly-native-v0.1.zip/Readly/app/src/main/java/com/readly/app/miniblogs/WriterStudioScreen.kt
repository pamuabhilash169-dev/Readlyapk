package com.readly.app.miniblogs

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.readly.app.auth.AuthManager
import com.readly.app.data.Cloudinary
import com.readly.app.data.FirebaseManager
import com.readly.app.data.Post
import com.readly.app.data.categories
import com.readly.app.ui.components.ReadlyTopBar
import kotlinx.coroutines.launch

@Composable
fun WriterStudioScreen(editId: String?, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var existing by remember { mutableStateOf<Post?>(null) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(categories.first()) }
    var imageUrl by remember { mutableStateOf("") }
    var localImage by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(editId) {
        if (!editId.isNullOrEmpty()) FirebaseManager.post(editId)?.let {
            existing = it; title = it.title; body = it.body; cat = it.category; imageUrl = it.imageUrl
        }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) localImage = it }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        ReadlyTopBar(if (existing == null) "New post" else "Edit post", onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(body, { body = it }, label = { Text("Write something…") }, modifier = Modifier.fillMaxWidth().heightIn(min = 200.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { c -> FilterChip(cat == c, { cat = c }, label = { Text(c) }) }
            }
            (localImage?.toString() ?: imageUrl.takeIf { it.isNotEmpty() })?.let {
                AsyncImage(it, null, Modifier.fillMaxWidth().height(180.dp), contentScale = ContentScale.Crop)
            }
            OutlinedButton({ pick.launch("image/*") }) { Text(if (localImage != null || imageUrl.isNotEmpty()) "Change image" else "Add image") }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
        Button(
            onClick = {
                busy = true; error = null
                scope.launch {
                    try {
                        val url = localImage?.let { Cloudinary.uploadImage(ctx, it) } ?: imageUrl
                        val u = AuthManager.user!!
                        val base = existing ?: Post(authorId = u.uid,
                            authorName = u.displayName?.takeIf { it.isNotBlank() } ?: "Reader", createdAt = System.currentTimeMillis())
                        FirebaseManager.save(base.copy(title = title.trim(), body = body.trim(), category = cat, imageUrl = url))
                        nav.popBackStack()
                    } catch (e: Exception) { error = e.message ?: "Couldn't publish"; busy = false }
                }
            },
            enabled = !busy && title.isNotBlank() && body.isNotBlank(),
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
        ) { Text(if (busy) "Publishing…" else if (existing == null) "Publish" else "Update") }
    }
}
