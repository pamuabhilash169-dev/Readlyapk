package com.readly.app.data

import android.content.Context
import android.net.Uri
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object FirebaseManager {
    private val posts get() = FirebaseFirestore.getInstance().collection("posts")

    suspend fun feed(tab: String, uid: String?): List<Post> {
        val q = when (tab) {
            "Popular" -> posts.orderBy("likes", Query.Direction.DESCENDING).limit(50)
            "My Posts" -> posts.whereEqualTo("authorId", uid ?: "")
            else -> posts.orderBy("createdAt", Query.Direction.DESCENDING).limit(50)
        }
        val list = q.get().await().documents.mapNotNull { d ->
            d.toObject(Post::class.java)?.copy(id = d.id)
        }
        return if (tab == "My Posts") list.sortedByDescending { it.createdAt } else list
    }

    suspend fun post(id: String): Post? {
        val d = posts.document(id).get().await()
        return d.toObject(Post::class.java)?.copy(id = d.id)
    }

    suspend fun save(p: Post) {
        val ref = if (p.id.isEmpty()) posts.document() else posts.document(p.id)
        ref.set(p.copy(id = ref.id)).await()
    }

    suspend fun delete(id: String) { posts.document(id).delete().await() }
}

/** Unsigned upload only. No API secret lives in the app. */
object Cloudinary {
    private const val CLOUD = "dbo82h9hl"

    suspend fun uploadImage(ctx: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val b = "----readly${System.currentTimeMillis()}"
        val conn = URL("https://api.cloudinary.com/v1_1/$CLOUD/image/upload").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
        conn.outputStream.use { o ->
            o.write("--$b\r\nContent-Disposition: form-data; name=\"upload_preset\"\r\n\r\nreadly_covers\r\n".toByteArray())
            o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"img\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray())
            ctx.contentResolver.openInputStream(uri)!!.use { it.copyTo(o) }
            o.write("\r\n--$b--\r\n".toByteArray())
        }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (code !in 200..299) error("Image upload failed ($code)")
        JSONObject(text).getString("secure_url")
    }
}
