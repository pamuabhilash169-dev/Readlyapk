package com.readly.app.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.readly.app.auth.AuthManager
import com.readly.app.data.LocalStorage
import com.readly.app.ui.components.ReadlyCard
import com.readly.app.ui.theme.ThemeState
import java.io.File

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val store = remember { LocalStorage(ctx) }
    var font by remember { mutableFloatStateOf(store.fontSize.toFloat()) }
    val user = AuthManager.user
    val usedMb = remember { File(ctx.filesDir, "books").walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1_048_576.0 }

    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        ReadlyCard(Modifier.fillMaxWidth()) {
            Text("My Account", style = MaterialTheme.typography.titleMedium)
            Text(user?.displayName ?: "Reader")
            Text(user?.email ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ReadlyCard(Modifier.fillMaxWidth()) {
            Text("Appearance", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("dark" to "Dark", "light" to "Light", "system" to "System").forEach { (k, label) ->
                    FilterChip(ThemeState.mode == k, { ThemeState.mode = k; store.theme = k }, label = { Text(label) })
                }
            }
        }
        ReadlyCard(Modifier.fillMaxWidth()) {
            Text("Reading preferences", style = MaterialTheme.typography.titleMedium)
            Text("Text size: ${font.toInt()} (TXT books)", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(font, { font = it; store.fontSize = it.toInt() }, valueRange = 12f..34f)
        }
        ReadlyCard(Modifier.fillMaxWidth()) {
            Text("Offline", style = MaterialTheme.typography.titleMedium)
            Text("Books on this device: ${store.books().size} (${"%.1f".format(usedMb)} MB)", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ReadlyCard(Modifier.fillMaxWidth()) {
            Text("Privacy", style = MaterialTheme.typography.titleMedium)
            Text("Your books stay on this device. Only Mini Blog posts are stored in the cloud.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Button(
            onClick = { store.clearSession(); AuthManager.signOut() }, // nav listener returns to Login
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) { Text("Log Out") }
    }
}
