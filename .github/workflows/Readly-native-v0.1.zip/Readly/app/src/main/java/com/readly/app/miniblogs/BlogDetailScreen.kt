package com.readly.app.miniblogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.readly.app.auth.AuthManager
import com.readly.app.data.FirebaseManager
import com.readly.app.data.Post
import com.readly.app.ui.components.Centered
import com.readly.app.ui.components.ReadlyTopBar
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun BlogDetailScreen(id: String, nav: NavHostController) {
    var post by remember { mutableStateOf<Post?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(id) {
        try { post = FirebaseManager.post(id) ?: run { error = "Post not found"; null } }
        catch (e: Exception) { error = e.message ?: "Couldn't load post" }
    }
    val p = post
    val mine = p != null && p.authorId == AuthManager.user?.uid
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        ReadlyTopBar("Post", onBack = { nav.popBackStack() }, actions = {
            if (mine) {
                IconButton({ nav.navigate("writer?id=$id") }) { Icon(Icons.Default.Edit, "Edit") }
                IconButton({ confirm = true }) { Icon(Icons.Default.Delete, "Delete") }
            }
        })
        when {
            error != null -> Centered(error!!)
            p == null -> Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
            else -> Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (p.imageUrl.isNotEmpty()) AsyncImage(p.imageUrl, null, Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = ContentScale.Crop)
                Text(p.title, style = MaterialTheme.typography.headlineMedium)
                Text("${p.authorName} · ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(p.createdAt))} · ${p.category}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(p.body, style = MaterialTheme.typography.bodyLarge, lineHeight = androidx.compose.ui.unit.TextUnit(26f, androidx.compose.ui.unit.TextUnitType.Sp))
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("Delete post?") },
        confirmButton = { TextButton({ scope.launch { runCatching { FirebaseManager.delete(id) }; nav.popBackStack() } }) { Text("Delete") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
    )
}
