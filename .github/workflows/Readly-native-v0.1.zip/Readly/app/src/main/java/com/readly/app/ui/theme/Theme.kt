package com.readly.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.readly.app.data.LocalStorage

object ThemeState { var mode by mutableStateOf("dark") } // dark | light | system

val Amber = Color(0xFFE7A03C)
val Teal = Color(0xFF4FA9A0)

private val Dark = darkColorScheme(
    primary = Amber, onPrimary = Color(0xFF1A1200), secondary = Teal, onSecondary = Color(0xFF00201D),
    background = Color(0xFF14171C), onBackground = Color(0xFFF1EDE4),
    surface = Color(0xFF14171C), onSurface = Color(0xFFF1EDE4),
    surfaceVariant = Color(0xFF1E222B), onSurfaceVariant = Color(0xFF9AA0AB),
    outline = Color(0xFF2C313B)
)
private val Light = lightColorScheme(
    primary = Color(0xFFB9701A), secondary = Color(0xFF2F8078),
    background = Color(0xFFFAF7F0), surface = Color(0xFFFAF7F0), surfaceVariant = Color(0xFFEFE9DC)
)
private val Serif = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
private val Type = Typography(
    headlineMedium = Serif.copy(fontSize = 28.sp), titleLarge = Serif.copy(fontSize = 22.sp),
    titleMedium = Serif.copy(fontSize = 18.sp)
)

@Composable
fun ReadlyTheme(store: LocalStorage, content: @Composable () -> Unit) {
    remember { ThemeState.mode = store.theme; 0 }
    val dark = when (ThemeState.mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Type) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
