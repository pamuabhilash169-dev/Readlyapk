package com.readly.app.data

data class Book(
    val id: String, val title: String, val author: String,
    val file: String, val type: String, val size: Long, val added: Long
)

// No-arg defaults so Firestore can deserialize it.
data class Post(
    val id: String = "", val title: String = "", val body: String = "",
    val category: String = "General", val imageUrl: String = "",
    val authorId: String = "", val authorName: String = "",
    val createdAt: Long = 0, val likes: Long = 0
)

val categories = listOf("General", "Reviews", "Self-Help", "Fiction", "Non-Fiction", "Poetry")
