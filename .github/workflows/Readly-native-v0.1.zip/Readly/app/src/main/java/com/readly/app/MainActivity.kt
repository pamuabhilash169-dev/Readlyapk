package com.readly.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.readly.app.data.LocalStorage
import com.readly.app.navigation.AppNavigation
import com.readly.app.ui.theme.ReadlyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = LocalStorage(applicationContext)
        setContent { ReadlyTheme(store) { AppNavigation() } }
    }
}
